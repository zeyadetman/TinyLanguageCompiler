# TinyLanguageCompiler
Compiler for Tiny programming language
